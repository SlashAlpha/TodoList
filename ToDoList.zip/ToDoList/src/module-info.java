module ToDoList {
    requires javafx.fxml;
    requires javafx.controls;

    opens com.learning.duprat.todolist;
}