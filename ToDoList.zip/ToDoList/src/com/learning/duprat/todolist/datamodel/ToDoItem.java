package com.learning.duprat.todolist.datamodel;

import java.time.LocalDate;

public class ToDoItem {
            private String shortDescription;
            private String details;
            private LocalDate deadLine;
            private int remaining;
            private boolean completed;
            private String fileInformation;

    public ToDoItem(String shortDescription, String details, LocalDate deadLine,int remaining,boolean completed,String fileInformation) {
        this.shortDescription = shortDescription;
        this.details = details;
        this.deadLine = deadLine;
        this.remaining=remaining;
        this.completed=completed;
        this.fileInformation=fileInformation;

    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public LocalDate getDeadLine() {
        return deadLine;
    }

    public void setDeadLine(LocalDate deadLine) {
        this.deadLine = deadLine;
    }

    public int getRemaining() {
        return remaining;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public String getFileInformation() {
        return fileInformation;
    }

    public void setFileInformation(String fileInformation) {
        this.fileInformation = fileInformation;
    }

    public void setRemaining(int remaining) {
        this.remaining = remaining;
    }

//    @Override
//    public String toString() {
//        return shortDescription;
//    }
}
