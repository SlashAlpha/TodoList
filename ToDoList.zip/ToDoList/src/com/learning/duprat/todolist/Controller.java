package com.learning.duprat.todolist;

import com.learning.duprat.todolist.datamodel.ToDoData;
import com.learning.duprat.todolist.datamodel.ToDoItem;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.util.Callback;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;

public class Controller {
    private List<ToDoItem> toDoItems;
    @FXML
    private ListView<ToDoItem> todoListView;

    @FXML
    private TextArea description;
    @FXML
    private Label deadlineLabel;
    @FXML
    private BorderPane mainBorderPane;
    @FXML
    private Label reminder;

    @FXML
    private ContextMenu listContextMenu;
    @FXML
    private Label startDay;
    @FXML
    private ToggleButton filterToggleButton;
    @FXML
    private ToggleButton filterToggleButton2;
    @FXML
    private TextArea fileInfo;
    @FXML
    private Label completed;


    private FilteredList<ToDoItem>filteredList;
    private Predicate<ToDoItem> wantPriorityItems;
    private Predicate<ToDoItem> wantAllItems;
    private Predicate<ToDoItem> wantTodaysItems;



    
    public void initialize(){
        listContextMenu=new ContextMenu();
        MenuItem deleteMenuItem=new MenuItem("Delete");
        deleteMenuItem.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                ToDoItem item=todoListView.getSelectionModel().getSelectedItem();
                deleteItem(item);
            }
        });
        listContextMenu.getItems().addAll(deleteMenuItem);
//        ToDoItem item=new ToDoItem("Death Cards","Invitation to see you in the ground",
//                LocalDate.of(2019, Month.JULY, 14));
//        ToDoItem item2=new ToDoItem("Doctor Appointment","Autopsy case 5062",
//                LocalDate.of(2019, Month.JULY, 19));
//        ToDoItem item3=new ToDoItem("Undertakers","Make up and clothing,fitting the box",
//                LocalDate.of(2019, Month.JULY, 20));
//        ToDoItem item4=new ToDoItem("Digging","Digging your hole at cemetary",
//                LocalDate.of(2019, Month.JULY, 21));
//        ToDoItem item5=new ToDoItem("Celebration","Burial,Photos and Canapé",
//                LocalDate.of(2019, Month.JULY, 22));
//        toDoItems=new ArrayList<>();
//        toDoItems.add(item);
//        toDoItems.add(item2);
//        toDoItems.add(item3);
//        toDoItems.add(item4);
//        toDoItems.add(item5);
//        ToDoData.getInstance().setToDoItems(toDoItems);
          todoListView.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<ToDoItem>() {
              @Override
              public void changed(ObservableValue<? extends ToDoItem> observableValue, ToDoItem toDoItem, ToDoItem t1) {
                  if (t1 != null) {
                      ToDoItem item=todoListView.getSelectionModel().getSelectedItem();
                      description.setText(item.getDetails());
                      fileInfo.setText(item.getFileInformation());

                      DateTimeFormatter df =DateTimeFormatter.ofPattern("EEEE d MMMM YYYY");
                      deadlineLabel.setText(df.format(item.getDeadLine()));
                      if(!item.isCompleted()){
                      completed.setText(String.valueOf(item.isCompleted()));
                      int i=item.getDeadLine().getDayOfYear()-LocalDate.now().getDayOfYear();

                      if(item.getDeadLine().getYear()==LocalDate.now().getYear()){
                    reminder.setText(Integer.toString(i));
                    if(i-item.getRemaining()>0){ startDay.setText(" begin in "+Integer.toString(i-item.getRemaining())+" days");}
                     else{startDay.setText("Started for "+(-(i-item.getRemaining()))+" days");}
                      }else{double s=(LocalDate.now().getYear()-item.getDeadLine().getYear())*365.25;
                    reminder.setText(Double.toString((s+item.getDeadLine().getDayOfYear())));
                    startDay.setText("Over");}

                      }else{startDay.setText("");reminder.setText("");
                      completed.setText(String.valueOf(item.isCompleted()));}

                  
                  }
              }
          });
          wantAllItems=new Predicate<ToDoItem>() {
              @Override
              public boolean test(ToDoItem item) {
                  return true;
              }
          };
          wantTodaysItems=new Predicate<ToDoItem>() {
              @Override
              public boolean test(ToDoItem item) {
                  return item.getDeadLine().equals(LocalDate.now());
              }
          };
          wantPriorityItems=new Predicate<ToDoItem>() {
              @Override
              public boolean test(ToDoItem item) {

                  return item.getDeadLine().getDayOfYear()-LocalDate.now().getDayOfYear()-item.getRemaining()<=0 && !item.isCompleted();
              }
          };

        filteredList=new FilteredList<ToDoItem>(ToDoData.getInstance().getToDoItems(), wantAllItems);

        SortedList<ToDoItem>sortedList=new SortedList<ToDoItem>(filteredList, new Comparator<ToDoItem>() {
            @Override
            public int compare(ToDoItem o1, ToDoItem o2) {
                return o1.getDeadLine().compareTo(o2.getDeadLine());
            }
        });

//        todoListView.setItems(ToDoData.getInstance().getToDoItems());
        todoListView.setItems(sortedList);
        todoListView.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        todoListView.getSelectionModel().selectFirst();

        todoListView.setCellFactory(new Callback<ListView<ToDoItem>, ListCell<ToDoItem>>() {
            @Override
            public ListCell<ToDoItem> call(ListView<ToDoItem> toDoItemListView) {
                ListCell<ToDoItem> cell = new ListCell<>(){
                    @Override
                    protected void updateItem(ToDoItem item, boolean b) {
                        super.updateItem(item, b);
                        if(b){setText(null);}else{ setText(item.getShortDescription());
                        if(item.isCompleted()){setTextFill(Color.BLUE);setText(item.getShortDescription()+" : completed");}
                       else if(item.getDeadLine().isBefore(LocalDate.now().plusDays(1))){setTextFill(Color.RED);}else
                        if(item.getDeadLine().getDayOfYear()-LocalDate.now().getDayOfYear()<=item.getRemaining()){setTextFill(Color.ORANGE);}
                        else{setTextFill(Color.GREEN);}}
                    }
                };
                cell.emptyProperty().addListener(
                        (obs,wasEmpty,isNowEmpty) ->{
                                if(isNowEmpty){cell.setContextMenu(null);}
                                else{cell.setContextMenu(listContextMenu);}
                        }
                );
                return cell;
            }
        });
    }
    @FXML
    public void showNewItemDialog(){
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.initOwner(mainBorderPane.getScene().getWindow());
        dialog.setTitle(" Add New ToDO");
        dialog.setHeaderText("Use this dialog to create a new ToDO Item");
        FXMLLoader fxmlLoader=new FXMLLoader();
        fxmlLoader.setLocation(getClass().getResource("todoitemDialog.fxml"));
        try{
            dialog.getDialogPane().setContent(fxmlLoader.load());
        } catch (IOException e){
            System.out.println("Couldn't load the dialog window");
            e.printStackTrace();
            return;
        }
        dialog.getDialogPane().getButtonTypes().add(ButtonType.OK);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CANCEL);
        Optional<ButtonType> result=dialog.showAndWait();
        if(result.isPresent() && result.get()==ButtonType.OK){
            DialogController controller= fxmlLoader.getController();
           ToDoItem newItem= controller.processResult();
//            todoListView.getItems().setAll(ToDoData.getInstance().getToDoItems());
            todoListView.getSelectionModel().select(newItem);

    }
    }

    @FXML
    public void handleClickListView(){
         ToDoItem item=selectedItem();
//         StringBuilder sb = new StringBuilder(item.getDetails());
//          sb.append("\n\n\n\n");
         
         
          
        description.setText(item.getDetails());
        deadlineLabel.setText(item.getDeadLine().toString());
    }
    @FXML
    public void handleKeyPressed(KeyEvent keyEvent){
       ToDoItem selectedItem =selectedItem();
       if(selectedItem!=null){
           if(keyEvent.getCode().equals(KeyCode.DELETE)){deleteItem(selectedItem);}
       }

    }

    public void deleteItem(ToDoItem item){
        Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete ToDO Item");
        alert.setHeaderText("Delete item: "+item.getShortDescription());
        alert.setContentText("Are you sure,data will be lost ,press OK to confirm");
        Optional<ButtonType> result = alert.showAndWait();
        if(result.isPresent() && (result.get())==ButtonType.OK){
            ToDoData.getInstance().deleteTodoItem(item);
        }
    }
    @FXML
    public void handleFilterButton(){
        ToDoItem selectedItem=selectedItem();
        if(filterToggleButton.isSelected()){
                filteredList.setPredicate(wantTodaysItems);
                if(filteredList.isEmpty()){description.clear();
                deadlineLabel.setText("");reminder.setText("");startDay.setText("");}
                else if(filteredList.contains(selectedItem)){
                    todoListView.getSelectionModel().select(selectedItem);}
                else{todoListView.getSelectionModel().selectFirst();}
        }else {
                filteredList.setPredicate(wantAllItems);
                todoListView.getSelectionModel().select(selectedItem);
        }

    }

    public void handleFilterButton2(){
        ToDoItem selectedItem=selectedItem();
        if(filterToggleButton2.isSelected()){
            filteredList.setPredicate(wantPriorityItems);
            if(filteredList.isEmpty()){description.clear();
                deadlineLabel.setText("");reminder.setText("");startDay.setText("");}
            else if(filteredList.contains(selectedItem)){
                todoListView.getSelectionModel().select(selectedItem);}
            else{todoListView.getSelectionModel().selectFirst();}

        }else {
            filteredList.setPredicate(wantAllItems);
            todoListView.getSelectionModel().select(selectedItem);
        }
    }
    @FXML
    public void handleExit(){
        Platform.exit();
    }

    public void completeTask(){

        ToDoItem item =selectedItem();
        String s="";
        if(item.isCompleted()){ s="unfinished";}else{ s="completed";}
        Alert alert=new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirm"+s+" Task");
        alert.setHeaderText("Is the mission "+item.getShortDescription()+" "+s+" ?");
        alert.setContentText("Task will be registered as "+s+", press OK to confirm");
        Optional<ButtonType> result = alert.showAndWait();
        if(result.isPresent() && (result.get())==ButtonType.OK){
        if(item.isCompleted()){item.setCompleted(false);}else{item.setCompleted(true);}
        todoListView.getSelectionModel().selectFirst();
        todoListView.getSelectionModel().select(item);}

    }

    public ToDoItem selectedItem(){
       return todoListView.getSelectionModel().getSelectedItem();
    }
}
